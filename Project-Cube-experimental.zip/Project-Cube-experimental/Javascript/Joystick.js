toggleJoystick = function(a) {
  a.style.display = "none" === a.style.display ? "block" : "none";
};